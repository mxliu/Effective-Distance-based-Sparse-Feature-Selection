function [ED_Similarity, effectDist] = EffectiveDistance(P,lambda)
%
%% Function EffectiveDistance
%   To compute similarity matrix by using the the effective distance.
%   Such effective distance is computed based on the sparse reconstruction coefficients.
%   The SLEP toolbox is used to execute the sparse reconstruction.

%% Input parameters:
%  P-        Matrix of data (size n x m), each row is a instance, each column is a feature;
%  lambda -  Bandwidth of the expotional function

%% Output parameters:
%  ED_S-     Similarity matrix based on the effective distance 
%
%%  Written by Mingxia Liu  2013.01.14


  addpath(genpath('SLEP'));
  
  [n,size_n]=size(P);
  ED_S = ones(n, n)/n;
%% To construct the directed graph using sparse representation
% If the sampe number is larger than the feature number,use the standard model��
% Otherwise, to use the extended model.
  option = [];
  if n>size_n
      option.mode = 'standard';
  else
      option.mode='extend';
  end  
  [sparse_W] = constructW1(P', option);

%%  Use the sparse_W to compute the effective distance
  mm = mean(sparse_W);
  staticP = zeros(n,n);
  for i = 1:size(sparse_W,1)
      staticP(i,:) = sparse_W(i,:)./mm;
  end
  effectDist = 1-log(staticP);

%% To compute the similarity matrix based on the effective distance
  bandWidth = mean(mean(dist(P,P'))); % The mean of all training samples
% lambda=[0.00001;0.001;0.01;0.1;1;100;1000;100000];% The parameter can be tuned
  ED_Similarity = exp(-(effectDist)/(lambda*bandWidth)); 

end
