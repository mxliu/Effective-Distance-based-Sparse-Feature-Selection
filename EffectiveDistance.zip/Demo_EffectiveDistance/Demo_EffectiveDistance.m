function Demo_EffectiveDistance
%
%% Function EffectiveDistance
%   To compute similarity matrix by using the the effective distance.
%   Such effective distance is computed based on the sparse reconstruction coefficients.
%   The SLEP toolbox is used to execute the sparse reconstruction.

%% Input parameters:
%  P-        Matrix of data (size n x m), each row is a instance, each column is a feature;
%  lambda -  Bandwidth of the expotional function

%% Output parameters:
%  ED_S-     Similarity matrix based on the effective distance 
%


P = rand(10,3) + 10;
lambda = 0.1;
[ED_Similarity, effectDist]  = EffectiveDistance(P,lambda);


end
